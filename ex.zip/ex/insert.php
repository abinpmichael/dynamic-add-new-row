<?php
//insert.php;

if(isset($_POST["user_id"]))
{
 $connect = new PDO("mysql:host=localhost;dbname=sarde", "root", "");
 $order_id = uniqid();
 for($count = 0; $count < count($_POST["user_id"]); $count++)
 {  
  $query = "INSERT INTO projectsadding 
  ( userid, projectids) 
  VALUES (:user_id,:project_id)
  ";
  $statement = $connect->prepare($query);
  $statement->execute(
   array(
   
    ':user_id'  => $_POST["user_id"][$count], 
    ':project_id' => $_POST["project_id"][$count]
   )
  );
 }
 $result = $statement->fetchAll();
 if(isset($result))
 {
  echo '<script>alert("succful");</script>';
 }
}
?>

